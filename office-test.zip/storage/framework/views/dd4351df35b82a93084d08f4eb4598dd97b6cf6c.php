<!DOCTYPE html>
<html>
<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <?php echo toastr_css(); ?>
</head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12" style="margin-top: 25px;">
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary" style="float: right;">Add Product</a>
                    <button type="button" class="btn btn-danger delete_all">Delete</button>
                </div>
                <div class="card" style="margin-top: 20px;">
                    <div class="card-body">
                        <div class="col-md-12">
                            <table class="table table-bordered table-striped">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Product Name</th>
                                    <th scope="col">Sku</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Image</th>
                                    <th scope="col">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><input type="checkbox" class="sub_chk" data-id="<?php echo e($product->id); ?>"></th>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->sku); ?></td>
                                            <td><?php echo e($product->price); ?></td>
                                            <td><img src="<?php echo e(asset($product->image)); ?>" width="100" alt=""></td>
                                            <td style="display: flex;">
                                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit Product">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                &nbsp;
                                                &nbsp;
                                                <form method="POST" action="<?php echo e(route('products.destroy', $product->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger delete-product" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete Product">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </form>
                                                &nbsp;
                                                &nbsp;
                                                <a href="<?php echo e(route('add-images', $product->id)); ?>" class="btn btn-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="Add Products">
                                                    <i class="fas fa-images"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Modal -->
    </body>
<?php echo jquery(); ?>
<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>

<script>
    $('.delete-product').click(function(e){
        e.preventDefault() // Don't post the form, unless confirmed
        if (confirm('Are you sure?')) {
            // Post the form
            $(e.target).closest('form').submit() // Post the surrounding form
        }
    });

    $('.delete_all').on('click', function(e) {
        var allVals = [];
        $(".sub_chk:checked").each(function() {
            allVals.push($(this).attr('data-id'));
        });
        if(allVals.length <=0)
        {
            alert("Please select row.");
        }  else {
            var check = confirm("Are you sure you want to delete this row?");
            if(check === true){
                var join_selected_values = allVals.join(",");
                $.ajax({
                    url: '<?php echo e(route('delete.multiple')); ?>',
                    type: 'DELETE',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: 'ids='+join_selected_values,
                    success: function (data) {
                        if (data['success']) {
                            $(".sub_chk:checked").each(function() {
                                $(this).parents("tr").remove();
                            });
                            alert(data['success']);
                        } else if (data['error']) {
                            alert(data['error']);
                        } else {
                            alert('Whoops Something went wrong!!');
                        }
                    },
                    error: function (data) {
                        alert(data.responseText);
                    }
                });
                $.each(allVals, function( index, value ) {
                    $('table tr').filter("[data-row-id='" + value + "']").remove();
                });
            }
        }
    });
</script>
</html>
<?php /**PATH C:\Users\nites\Desktop\work in progress\test-project-office\resources\views/products/index.blade.php ENDPATH**/ ?>